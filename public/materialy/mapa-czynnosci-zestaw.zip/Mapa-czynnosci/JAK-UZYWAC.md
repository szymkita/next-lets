# Mapa czynności — jak przeprowadzić ją w tydzień

Zestaw od Let's automate dla osoby, która prowadzi wdrożenie AI w firmie. Zespół spisuje swoją pracę
w arkuszu, a skill „Mapa czynności” w Waszym AI prowadzi Cię przez analizę: co może przejąć AI, co system,
a co zostaje u ludzi. Działa w Claude, ChatGPT, Copilocie, Gemini i Appto. Nikomu niczego nie wysyłacie.

Metodę opracowaliśmy na bazie naszych wdrożeń AI. Tu jest w uproszczonej formie, do samodzielnej pracy.
Nie potrzebujecie spisanych procesów ani dokumentacji: mapa zbiera je z codziennej pracy, także tej, która
dzieje się obok procesów.

## Kto co dostaje

- **Zespół:** tylko arkusz `Mapa-czynnosci.xlsx` (każdy swoją kopię) i wiadomość od Ciebie. Arkusz wypełnia
  ręcznie, w trakcie pracy. Zespół nie potrzebuje żadnego AI.
- **Ty:** skill „Mapa czynności”. Wklejasz do niego zebrane arkusze, a on prowadzi Cię przez pięć etapów.

## Co jest w zestawie

| Plik | Do czego |
|---|---|
| `Mapa-czynnosci.xlsx` | arkusz dla każdej osoby z zespołu |
| `Wiadomosc-do-zespolu.txt` | gotowy tekst na Slacka, Teams albo mail |
| `skill/mapa-czynnosci.zip` | skill do wgrania w Claude |
| `skill/mapa-czynnosci/` | ten sam skill jako pliki: `SKILL.md` i pięć etapów w `etapy/` (do ChatGPT, Copilota, Gemini, Appto) |

Pięć etapów skilla:
1. **Sprawdzenie arkuszy** — pytania do każdej osoby, co doprecyzować (odsyłasz je, ludzie poprawiają sami).
2. **Diagnoza zespołu** — gdzie idzie czas, ile pracy dzieje się obok procedur, trzy procesy na start.
3. **Jeden standard** — najlepszy sposób pracy, gdy ten sam proces każdy robi inaczej.
4. **AI, system czy człowiek** — każdy krok na swoim miejscu; co zrobicie sami, a co trzeba zbudować.
5. **Plan dla zarządu** — jedna strona z rachunkiem na Waszych stawkach i planem na 30 dni.

## Tydzień

| Dzień | Kto | Co |
|---|---|---|
| Poniedziałek | Ty | wysyłasz zespołowi wiadomość i arkusz, mówisz w 15 minut, po co to robicie |
| Wtorek–czwartek | zespół | każdy wpisuje czynności w swój arkusz na bieżąco, kilka minut dziennie |
| Czwartek | Ty | zbierasz arkusze i robisz etap 1; pytania odsyłasz ludziom |
| Piątek | zespół | poprawia arkusze według pytań i oddaje |
| Piątek–poniedziałek | Ty | etapy 2–5: diagnoza, standard i podział dla 1–3 procesów, plan dla zarządu |

Kilka dni jest ważne: z głowy pamiętamy duże rzeczy, a najwięcej czasu zjadają drobiazgi (przeklejanie,
szukanie, przypominanie). Każdy wypełnia swój arkusz sam. Porównujecie dopiero potem.

## Jak włączyć skill

- **Claude** (claude.ai, plan Pro, Max, Team albo Enterprise): Ustawienia → Możliwości → Skills → prześlij
  `mapa-czynnosci.zip`. Potem w nowej rozmowie załącz arkusze i napisz „mapa czynności”.
- **ChatGPT:** utwórz Projekt. W instrukcje projektu wklej treść `SKILL.md` (bez pierwszych linii między `---`),
  a pięć plików z `etapy/` dodaj jako pliki projektu.
- **Microsoft Copilot:** utwórz agenta. W instrukcje wklej treść `SKILL.md`, a pliki z `etapy/` dodaj jako wiedzę.
- **Gemini:** utwórz Gem. W instrukcje wklej treść `SKILL.md`, a pliki z `etapy/` dodaj jako pliki.
- **Appto:** utwórz agenta „Mapa czynności”, dodaj `SKILL.md` jako jego umiejętność, a pliki z `etapy/` do jego wiedzy.

## Dane

Nie wpisujcie nazwisk klientów ani danych osobowych: „klient”, „dostawca”, „technik” wystarczy.
Używajcie AI w planie firmowym, który już macie, zgodnie z zasadami Waszej firmy.

## Po mapie

Mapa pokaże, co AI może przejąć i co zrobicie sami od razu. Agentów AI, którzy przejmą te procesy na Waszych
programach, wdrażamy w Let's automate. Z gotową mapą od pierwszej rozmowy mówimy o budowie.
Pierwsza rozmowa: 30 minut, za darmo — letsautomate.pl/mapa-czynnosci#omowienie

Wolicie zrobić mapę z nami? Przeprowadzimy ten tydzień z Waszym zespołem.
