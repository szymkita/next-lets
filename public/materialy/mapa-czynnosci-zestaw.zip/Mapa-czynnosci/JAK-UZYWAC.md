# Mapa czynności — jak przeprowadzić ją w tydzień

Zestaw od Let's automate. Arkusz i pięć skilli, z którymi Twój zespół sprawdzi, co w Waszej pracy może przejąć
AI, a co system. Wszystko dzieje się w Waszym AI (Claude, ChatGPT, Copilot, Gemini albo Appto). Nikomu
niczego nie wysyłacie.

Metodę opracowaliśmy na bazie naszych wdrożeń AI. Tu jest w uproszczonej formie, do samodzielnej pracy.
Nie potrzebujecie spisanych procesów ani dokumentacji: mapa zbiera je z codziennej pracy, także tej, która
dzieje się obok procesów.

## Co jest w zestawie

| Plik | Do czego |
|---|---|
| `Mapa-czynnosci.xlsx` | arkusz: każda osoba dostaje swoją kopię |
| `Wiadomosc-do-zespolu.txt` | gotowy tekst na Slacka, Teams albo mail |
| `skille/sprawdz-arkusz` | jeden wypełniony arkusz → co doprecyzować, z pytaniem do każdego wiersza |
| `skille/diagnoza-zespolu` | wszystkie arkusze → gdzie idzie czas i trzy procesy na start |
| `skille/jeden-standard` | ten sam proces u kilku osób → jeden najlepszy sposób pracy |
| `skille/ai-system-czy-czlowiek` | proces → co zrobi AI, co system, co zostaje u człowieka |
| `skille/plan-dla-zarzadu` | wszystko razem → jedna strona dla zarządu z planem na 30 dni |

## Tydzień

| Dzień | Kto | Co |
|---|---|---|
| Poniedziałek | osoba prowadząca | wysyła zespołowi wiadomość i arkusz, mówi w 15 minut, po co to robicie |
| Wtorek–czwartek | każdy | wpisuje czynności w swój arkusz na bieżąco, kilka minut dziennie |
| Piątek | każdy | uzupełnia czas i częstotliwość, sprawdza arkusz skillem „Sprawdź arkusz”, poprawia i oddaje |
| Piątek | osoba prowadząca | wkleja wszystkie arkusze do „Diagnozy zespołu” |
| Poniedziałek | osoba prowadząca | „Jeden standard” i „AI, system czy człowiek” dla 1–3 procesów, potem „Plan dla zarządu” |

Kilka dni jest ważne: z głowy pamiętamy duże rzeczy, a najwięcej czasu zjadają drobiazgi (przeklejanie,
szukanie, przypominanie). Każdy wypełnia swój arkusz sam, w trakcie pracy. Porównujecie dopiero potem.

## Jak włączyć skille

Skill to instrukcja, którą AI wykonuje krok po kroku. Każdy jest w osobnym folderze z plikiem `SKILL.md`.

- **Claude** (claude.ai, plan Pro, Max, Team albo Enterprise): Ustawienia → Możliwości → Skills → prześlij plik
  ZIP skilla (`sprawdz-arkusz.zip` i pozostałe). Potem załącz arkusz i napisz np. „sprawdź mój arkusz”.
- **ChatGPT:** utwórz Projekt (albo własnego GPT), wklej treść `SKILL.md` w instrukcje. Jeden projekt na skill:
  „Sprawdź arkusz” może mieć cały zespół, pozostałe są dla osoby prowadzącej.
- **Microsoft Copilot:** utwórz agenta albo notatnik i wklej treść `SKILL.md` w instrukcje.
- **Gemini:** utwórz Gem i wklej treść `SKILL.md` w instrukcje.
- **Appto:** dodaj treść `SKILL.md` jako umiejętność nazwanego agenta (np. „Mapa czynności”); zespół pisze do
  tego agenta.

Arkusz zawsze wypełnia człowiek, ręcznie: tylko on wie, jak naprawdę pracuje. Skille wchodzą dopiero na
wypełnione arkusze i je analizują. Zespołowi wystarczy „Sprawdź arkusz”, cztery pozostałe są dla osoby, która
prowadzi mapę.

## Dane

Nie wpisujcie nazwisk klientów ani danych osobowych: „klient”, „dostawca”, „technik” wystarczy.
Używajcie AI w planie firmowym, który już macie, zgodnie z zasadami Waszej firmy.

## Po mapie

Mapa i skille pokażą, co AI może przejąć i co zrobicie sami od razu. Agentów AI, którzy przejmą te procesy
na Waszych programach, wdrażamy w Let's automate. Z gotową mapą od pierwszej rozmowy mówimy o budowie.
Pierwsza rozmowa: 30 minut, za darmo — letsautomate.pl/mapa-czynnosci#omowienie

Wolicie zrobić mapę z nami? Przeprowadzimy ten tydzień z Waszym zespołem.
