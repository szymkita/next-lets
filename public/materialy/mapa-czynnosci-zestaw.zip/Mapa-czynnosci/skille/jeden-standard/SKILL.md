---
name: jeden-standard
description: Porównuje, jak kilka osób w firmie robi ten sam proces (z arkuszy „Mapa czynności” albo opisów), i składa z tego jeden najlepszy sposób pracy, wypisując wiedzę, którą ma tylko jedna osoba. Użyj, gdy ktoś pyta „kto robi to najlepiej”, prosi o „standard procesu”, „porównanie, jak to robimy” albo przed oddaniem procesu AI.
---

# Jeden standard

W firmach ten sam proces każdy robi trochę inaczej. AI nie dostanie dobrej instrukcji, dopóki nie wiadomo,
który sposób jest najlepszy. Porównujesz wersje kilku osób i składasz jeden standard, którego może się nauczyć
nowa osoba, AI albo system.

## Zasada najważniejsza

Nie sklejaj wszystkich wersji w jedną listę kroków. Wybierz **jedną wersję jako bazę**, tę, która daje
najlepszy wynik przy najmniejszej pracy, i dołóż do niej tylko te elementy innych wersji, które coś poprawiają
(łapią błąd, oszczędzają krok, chronią przed pomyłką). Reszta wypada, z jednym zdaniem dlaczego.

## Wejście

Wiersze tego samego procesu od różnych osób: Gdy, Co, Jak, Po co, Czas, Częstotliwość, AI. Jeśli dostajesz całe
arkusze, najpierw zapytaj, który proces porównać, albo wybierz ten, który robi najwięcej osób.

## Kroki

1. **Rozpisz każdą wersję na kroki** z kolumny „Jak”. Każdy krok: czynność + narzędzie + skąd biorą się dane.
2. **Ułóż wersje obok siebie** w tabeli: wiersze to etapy procesu, kolumny to osoby. Puste pole = osoba tego nie
   robi. Zaznacz kroki, które robi tylko jedna osoba.
3. **Znajdź różnice, które mają znaczenie:**
   - kroki, które ktoś robi, a inni pomijają (czy to łapie błędy, czy to zbędna kontrola?);
   - różne źródła tych samych danych (jedna osoba bierze cenę z cennika, druga z ostatniej oferty);
   - różny czas jednego wykonania i z czego wynika;
   - kroki „czekam na…”, „pytam…”, „dzwonię do…” — gdzie proces zależy od innych ludzi.
4. **Wybierz bazę** i uzasadnij w 2–3 zdaniach.
5. **Wypisz wiedzę z głowy:** zasady, które ktoś stosuje, a których nie ma w żadnym dokumencie („klientom
   z umową ramową nie liczymy dojazdu”, „jak termin jest krótszy niż 3 dni, najpierw dzwonię do technika”).
   To najcenniejsza część, bo bez niej AI zrobi proces źle.
6. **Opisz granice procesu:** co go uruchamia, co jest na wejściu, co jest gotowym wynikiem, kto go odbiera.

## Wynik

1. **Tabela porównania** wersji (etapy × osoby).
2. **Standard:** numerowane kroki, przy każdym narzędzie, źródło danych i kto to robi dziś. Kroki dołożone
   z innych wersji oznacz „(z wersji: rola)”.
3. **Zasady z głowy** jako lista „Gdy… to…”, z informacją, kto je zna.
4. **Wejście i wynik procesu** w dwóch zdaniach.
5. **Pytania do zespołu**, bez których standardu nie da się zamknąć (maks. 5), skierowane do konkretnych ról.
6. **Co dalej:** gotowy standard wklej do skilla „AI, system czy człowiek”.

Nie przypisuj jeszcze kroków do AI. Ten skill kończy się na tym, jak proces powinien wyglądać, kiedy robi go
najlepsza osoba.
