---
name: diagnoza-zespolu
description: Czyta arkusze „Mapa czynności” całego zespołu, łączy te same procesy między ludźmi, liczy godziny w miesiącu i wskazuje procesy, od których warto zacząć wdrożenie AI. Użyj, gdy ktoś wkleja albo załącza kilka arkuszy czynności, prosi o „diagnozę zespołu”, „podsumowanie arkuszy” albo pyta, co z tej pracy może przejąć AI.
---

# Diagnoza zespołu

Dostajesz arkusze „Mapa czynności” od kilku osób z jednej firmy. Każdy wiersz to jedna czynność z kolumnami:
Gdy, Co, Jak, Po co, Czas (min), Częstotliwość, Czy i jak wykorzystujesz tu AI. Twoim zadaniem jest pokazać,
gdzie naprawdę idzie czas zespołu i od czego zacząć. Piszesz dla osoby, która prowadzi wdrożenie w firmie.

## Zasady

- Liczysz tylko z tego, co jest w arkuszach. Niczego nie dopisujesz. Szacunek oznaczasz słowem „ok.”.
- Wiersz zbyt ogólny (np. „obsługa klienta”, „maile”) albo bez czasu nie znika: trafia do listy „Do dopytania”.
- Nie oceniasz ludzi. Różnice między osobami to informacja o procesie, nie o pracownikach.
- Imiona z arkuszy możesz używać w wyniku tylko wtedy, gdy są w nazwach plików albo arkuszy. W raporcie dla
  zarządu (skill „Plan dla zarządu”) używaj ról, nie imion.

## Krok 1. Porządek danych

1. Wczytaj wszystkie arkusze. Przy każdym wierszu zapamiętaj osobę albo rolę (z nazwy pliku lub arkusza).
2. Pomiń wiersz-przykład („PRZYKŁAD”) i puste wiersze.
3. Zamień częstotliwość na liczbę wykonań w miesiącu. Jeśli w nawiasie jest konkretna liczba, użyj jej.
   Inaczej: Kilka razy dziennie = 60, Codziennie = 20, Kilka razy w tygodniu = 12, Raz w tygodniu = 4,
   Kilka razy w miesiącu = 3, Raz w miesiącu = 1, Raz na kwartał = 0,33, Rzadziej = 0,1.
4. Policz **minuty w miesiącu** = Czas × wykonania. Godziny = minuty / 60, zaokrąglij do 0,5 h.

## Krok 2. Te same procesy u różnych osób

Pogrupuj wiersze, które opisują ten sam proces, nawet innymi słowami (patrz na „Co” i „Po co”, potem na „Jak”).
Nazwij każdy proces krótko, od wyniku: „Przyjęcie zlecenia serwisowego”, „Wycena dla klienta”, „Raport
tygodniowy dla zarządu”. Dla każdego procesu zbierz:
- kto go robi (osoby albo role) i ile godzin w miesiącu łącznie;
- najkrótszy i najdłuższy czas jednego wykonania między osobami. Duża różnica (np. 10 min kontra 40 min)
  zwykle znaczy, że nie ma jednego sposobu pracy, i jest sygnałem do skilla „Jeden standard”;
- narzędzia, które pojawiają się w „Jak” (poczta, arkusze, CRM, ERP, dysk, telefon, komunikator);
- ile kroków to przenoszenie danych między narzędziami (przepisuję, kopiuję, wklejam, sprawdzam w…, wpisuję do…);
- czy ktoś już używa tu AI i jak.

## Krok 3. Ocena kandydatów

Dla każdego procesu oceń pięć rzeczy w skali 1–3 i krótko uzasadnij:

| Kryterium | 3 | 1 |
|---|---|---|
| Czas | dużo godzin w miesiącu w całym zespole | kilka godzin |
| Powtarzalność | robi się tak samo za każdym razem | za każdym razem inaczej |
| Dane pod ręką | wszystko jest w mailach, plikach, systemach | w głowach i rozmowach |
| Jasne kryteria | wiadomo, kiedy wynik jest dobry | ocena zależy od wyczucia |
| Koszt pomyłki | błąd łatwo wyłapać przed klientem | błąd idzie prosto do klienta albo pieniędzy |

Do tego wskaż, jaki rodzaj zmiany pasuje najbardziej:
- **AI w rozmowie** — tekst, analiza, odpowiedź, szkic oferty, streszczenie; człowiek sprawdza i wysyła;
- **System albo automatyzacja** — przenoszenie danych między narzędziami, reguły „jeśli… to…”, przypomnienia,
  raporty z danych, które już są w systemach;
- **Zostaje u człowieka** — decyzja, negocjacja, relacja, odpowiedzialność;
- **Do przebudowy** — proces robiony podwójnie, niepotrzebny albo czekanie na kogoś bez powodu.

Zwykle proces ma kroki kilku rodzajów. Podaj rodzaj, który daje najwięcej czasu.

## Wynik

1. **W jednym akapicie:** ile czynności, ile osób, ile godzin miesięcznie łącznie spisał zespół i gdzie idzie
   najwięcej (trzy największe procesy z godzinami).
2. **Trzy procesy na start.** Dla każdego: nazwa, kto robi, godziny w miesiącu, ocena 5 kryteriów, rodzaj
   zmiany, jedno zdanie „dlaczego od tego” i czego trzeba się dowiedzieć przed startem. Wybieraj procesy z dużą
   liczbą godzin i wysoką oceną, ale nie te, w których pomyłka od razu kosztuje klienta albo pieniądze.
3. **Pełna tabela procesów:** Proces | Kto | h/mies. | Czas 1 wykonania (min–max) | Narzędzia | Ocena (suma) |
   Rodzaj zmiany | AI dziś.
4. **Jak zespół używa AI dziś:** co już działa (warto pokazać innym), gdzie ludzie piszą „nie wiem, czy mogę”,
   „nie wiem jak”, „wychodzi źle”.
5. **Do dopytania:** wiersze zbyt ogólne, bez czasu, bez kroków w „Jak”, z pytaniem, które zadać konkretnej osobie.
6. **Dalej:** dla procesów, które robi kilka osób różnie, zaproponuj skill „Jeden standard”; dla wybranego
   procesu skill „AI, system czy człowiek”.

Nie obiecuj oszczędności w godzinach ani złotówkach. To policzy skill „Plan dla zarządu” na stawkach, które
poda firma.
