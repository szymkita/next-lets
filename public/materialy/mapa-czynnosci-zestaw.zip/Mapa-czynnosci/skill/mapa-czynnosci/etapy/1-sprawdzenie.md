# Etap 1. Sprawdzenie arkuszy

Osoba prowadząca zebrała arkusze od zespołu (jeden albo kilka). Sprawdzasz, czy da się z nich zrobić diagnozę,
i przygotowujesz pytania, które ona przekaże ludziom. Poprawki w swoich arkuszach każdy wpisuje sam.

**Nie wpisujesz niczego za pracowników.** Nie dopisujesz kroków, czasu ani wierszy i nie podajesz poprawionych
arkuszy. Tylko pytasz.

## Co sprawdzasz w każdym wierszu

| Problem | Po czym go poznać | Pytanie do tej osoby |
|---|---|---|
| Za szeroko | „Co” obejmuje cały obszar: „obsługa klienta”, „maile”, „sprawy biurowe” | „Co dokładnie się na to składa? Rozpisz każdą rzecz w osobnym wierszu.” |
| Za mało kroków | „Jak” to jedno zdanie albo brak narzędzi | pytanie o brakujący kawałek: „Skąd bierzesz cenę?”, „Gdzie to potem wpisujesz?”, „Co robisz, gdy czegoś brakuje?” |
| Brak celu | puste „Po co” albo „bo tak trzeba” | „Co by się stało, gdyby tego nie zrobić? Kto na tym korzysta?” |
| Brak czasu albo częstotliwości | puste pole albo „różnie” | „Na oko: ile minut zajmuje jedno wykonanie i ile razy w tygodniu to robisz?” |
| Puste AI | pusta ostatnia kolumna | „Czy używasz tu AI? Jeśli nie, napisz dlaczego.” |
| Dwie rzeczy w jednym | w „Co” albo „Jak” są dwie różne czynności | „To wygląda na dwie czynności. Rozdziel je na dwa wiersze.” |
| Dane osobowe | nazwiska klientów, numery, adresy | „Zamień na »klient«, »dostawca« itd.” |

Sprawdź też każdy arkusz jako całość:
- czy są drobiazgi, o których ludzie zwykle zapominają: odpisywanie na maile, przeklejanie danych, szukanie
  plików, przypominanie komuś, telefony, czekanie na kogoś. Jeśli ich nie ma, zapytaj o nie wprost;
- czy suma czasu ma sens. Licz minuty w miesiącu (Kilka razy dziennie = 60 wykonań, Codziennie = 20, Kilka razy
  w tygodniu = 12, Raz w tygodniu = 4, Kilka razy w miesiącu = 3, Raz w miesiącu = 1, Raz na kwartał = 0,33,
  Rzadziej = 0,1). Jeśli wychodzi dużo mniej niż etat, zapytaj, czego brakuje; jeśli dużo więcej, które czasy są
  zawyżone.

## Wynik

1. **Tabela stanu:** osoba (albo nazwa pliku) | czynności | godziny w miesiącu | gotowy do diagnozy (tak / prawie /
   jeszcze nie).
2. **Dla każdej osoby osobno** krótka wiadomość do przekazania, gotowa do skopiowania: życzliwie, na „Ty”,
   najwyżej 8 pytań, każde z numerem wiersza. Na końcu prośba, żeby poprawki wpisała w swoim arkuszu.
3. **Jedno zdanie, co dalej:** gdy większość arkuszy jest gotowa, można przejść do diagnozy; arkusze „prawie”
   nie blokują diagnozy, „jeszcze nie” lepiej uzupełnić.

Nie oceniaj pracy ludzi i nie podpowiadaj jeszcze, co da się zautomatyzować. To przyjdzie w diagnozie.
