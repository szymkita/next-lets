# Etap 4. AI, system czy człowiek

Dostajesz jeden proces: najlepiej standard z etapu 3 (Jeden standard), a jeśli go nie ma, wiersze z arkusza
„Mapa czynności”. Rozkładasz go na kroki i dla każdego decydujesz, kto go zrobi po zmianie. Piszesz dla osoby,
która będzie to wdrażać w firmie, prostym językiem biura.

## Trzy miejsca na krok

- **AI** — czytanie i pisanie tekstu, wyciąganie danych z maili, PDF i skanów, porównywanie z cennikiem albo
  umową, szkic odpowiedzi, oferty, podsumowania, sprawdzanie kompletności. AI potrzebuje kontekstu (zasad,
  cenników, przykładów dobrych wyników) i zwykle kogoś, kto zatwierdzi wynik.
- **System** — wszystko, co ma działać zawsze tak samo: przenoszenie danych między programami, reguły
  „jeśli… to…”, terminy i przypomnienia, numeracja, statusy, raporty z danych, które już są w systemach.
  Tu nie pytamy AI za każdym razem; krok ma być zbudowany raz i działać.
- **Człowiek** — decyzje, wyjątki, negocjacje, relacja z klientem, odpowiedzialność za pieniądze. Celem jest,
  żeby człowiek dostawał gotową sprawę z jednym pytaniem do decyzji, a nie zbierał dane.

Zasada: krok idzie do AI tylko wtedy, gdy da się opisać, jak wygląda dobry wynik, i da się go sprawdzić.
Gdy błąd AI szedłby prosto do klienta albo w pieniądze, dodaj krok „człowiek zatwierdza”.

## Kroki

1. **Lista kroków dziś.** Ponumeruj kroki procesu z narzędziem i czasem, jeśli jest znany.
2. **Przypisz każdy krok** do AI, systemu albo człowieka i podaj jedno zdanie dlaczego. Kroki, które po zmianie
   znikają (np. „przepisuję numer z maila do arkusza”), oznacz „znika” i napisz, co je zastępuje.
3. **Kontekst dla AI.** Dla kroków AI wypisz, co trzeba mu dać: dokumenty (cennik, umowy, procedury), zasady
   z głowy (ze etapu 3 (Jeden standard)), 3–5 przykładów dobrych wyników, słownik firmowych nazw. Przy każdym
   napisz, gdzie to dziś leży i kto to ma.
4. **Połączenia dla systemu.** Dla kroków systemu wypisz, które programy muszą się wymieniać danymi (np.
   poczta → system zamówień → kalendarz techników) i co dokładnie przechodzi (numer klienta, pozycje, termin).
   Nie zakładaj, że program ma gotowe połączenie; napisz „do sprawdzenia”, jeśli nie wiesz.
5. **Decyzje człowieka.** Dla kroków człowieka napisz, jakie pytanie dostaje i jakie informacje musi mieć przed
   oczami, żeby odpowiedzieć w minutę.
6. **Przypadki do testów.** Zaproponuj 5 prawdziwych sytuacji do sprawdzenia przed startem: 2 typowe, 2 trudne
   (brak danych, nietypowy klient), 1, w której AI powinno się zatrzymać i zapytać człowieka. Poproś, żeby
   firma podstawiła prawdziwe przykłady z ostatnich tygodni (bez danych osobowych).
7. **Kolejność budowy.** Zaproponuj, od którego kawałka zacząć, żeby za tydzień coś już działało (zwykle: AI
   robi szkic, człowiek zatwierdza; system dochodzi w drugim kroku).
8. **Sami czy z kimś, kto buduje.** Każdy krok AI i systemu przypisz do jednego z trzech poziomów i powiedz
   uczciwie, co z tego firma zrobi sama:
   - **Sami, od jutra:** człowiek wkleja do czatu AI dane i kontekst, AI robi szkic, człowiek kopiuje wynik dalej.
     Działa od razu, ale czas wraca tylko częściowo, bo ktoś dalej przenosi dane ręcznie.
   - **Agent AI na Waszych programach:** agent sam czyta pocztę i pliki, sprawdza w systemie, przygotowuje wynik
     i czeka na zatwierdzenie. Wymaga dostępów, zasad, testów i opieki. Zwykle buduje go firma wdrożeniowa albo
     własny zespół IT.
   - **Połączenie systemów:** dane same przechodzą między programami. Wymaga integracji, także ze starszymi
     programami bez gotowego połączenia.
   Przy każdym poziomie napisz, ile czasu z procesu odzyskuje się na nim (zakres), żeby było widać różnicę.

## Wynik

1. **Tabela:** Nr | Krok dziś | Narzędzie | Po zmianie (AI / system / człowiek / znika) | Dlaczego.
2. **Proces po zmianie** w kilku zdaniach, od wejścia do wyniku, z miejscami, gdzie człowiek zatwierdza.
3. **Lista kontekstu do zebrania** (co, gdzie leży, kto ma).
4. **Połączenia między programami** do sprawdzenia.
5. **Pięć przypadków do testów.**
6. **Pierwszy krok budowy** na najbliższy tydzień.
7. **Co zrobicie sami, a co trzeba zbudować:** tabela Krok | Poziom (sami / agent / połączenie) | Czas, który
   wraca (zakres), i jedno zdanie, co firma może zrobić sama od jutra.

Czasu po zmianie nie podawaj jako pewnika. Jeśli szacujesz, podaj zakres i napisz, od czego zależy.
