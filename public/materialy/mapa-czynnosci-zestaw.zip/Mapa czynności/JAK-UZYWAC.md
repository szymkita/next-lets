# Mapa czynności — jak przeprowadzić ją w tydzień

Zestaw od Let's automate. Arkusz i pięć skilli, z którymi Twój zespół sprawdzi, co w Waszej pracy może przejąć
AI, a co system. Wszystko dzieje się w Waszym AI (Claude, ChatGPT, Copilot, Gemini albo Appto). Nikomu
niczego nie wysyłacie.

## Co jest w zestawie

| Plik | Do czego |
|---|---|
| `Mapa-czynnosci.xlsx` | arkusz: każda osoba dostaje swoją kopię |
| `Wiadomosc-do-zespolu.txt` | gotowy tekst na Slacka, Teams albo mail |
| `skille/spisz-dzien` | 5 minut rozmowy na koniec dnia → gotowe wiersze arkusza |
| `skille/diagnoza-zespolu` | wszystkie arkusze → gdzie idzie czas i trzy procesy na start |
| `skille/jeden-standard` | ten sam proces u kilku osób → jeden najlepszy sposób pracy |
| `skille/ai-system-czy-czlowiek` | proces → co zrobi AI, co system, co zostaje u człowieka |
| `skille/plan-dla-zarzadu` | wszystko razem → jedna strona dla zarządu z planem na 30 dni |

## Tydzień

| Dzień | Kto | Co |
|---|---|---|
| Poniedziałek | osoba prowadząca | wysyła zespołowi wiadomość i arkusz, mówi w 15 minut, po co to robicie |
| Wtorek–czwartek | każdy | 5 minut na koniec dnia: skill „Spisz dzień” albo wpis prosto w arkusz |
| Piątek | każdy | porządkuje swój arkusz (skill „Spisz dzień” łączy powtórki) i oddaje |
| Piątek | osoba prowadząca | wkleja wszystkie arkusze do „Diagnozy zespołu” |
| Poniedziałek | osoba prowadząca | „Jeden standard” i „AI, system czy człowiek” dla 1–3 procesów, potem „Plan dla zarządu” |

Kilka dni jest ważne: z głowy pamiętamy duże rzeczy, a najwięcej czasu zjadają drobiazgi (przeklejanie,
szukanie, przypominanie). Każdy wypełnia swój arkusz sam, w trakcie pracy. Porównujecie dopiero potem.

## Jak włączyć skille

Skill to instrukcja, którą AI wykonuje krok po kroku. Każdy jest w osobnym folderze z plikiem `SKILL.md`.

- **Claude** (claude.ai, plan Pro, Max, Team albo Enterprise): Ustawienia → Możliwości → Skills → prześlij plik
  ZIP skilla (`spisz-dzien.zip` i pozostałe). Potem w rozmowie napisz np. „spisz mój dzień”.
- **ChatGPT:** utwórz Projekt (albo własnego GPT), wklej treść `SKILL.md` w instrukcje. Jeden projekt na skill:
  „Spisz dzień” dla zespołu, pozostałe dla osoby prowadzącej.
- **Microsoft Copilot:** utwórz agenta albo notatnik i wklej treść `SKILL.md` w instrukcje.
- **Gemini:** utwórz Gem i wklej treść `SKILL.md` w instrukcje.
- **Appto:** dodaj treść `SKILL.md` jako umiejętność nazwanego agenta (np. „Mapa czynności”); zespół pisze do
  tego agenta.

Nie trzeba instalować wszystkiego. Zespół potrzebuje tylko „Spisz dzień”. Cztery pozostałe są dla osoby,
która prowadzi mapę.

## Dane

Nie wpisujcie nazwisk klientów ani danych osobowych: „klient”, „dostawca”, „technik” wystarczy.
Używajcie AI w planie firmowym, który już macie, zgodnie z zasadami Waszej firmy.

## Po mapie

Masz plan dla zarządu i chcesz go z kimś omówić? Zrobimy to za darmo w 30 minut:
letsautomate.pl/mapa-czynnosci#omowienie
